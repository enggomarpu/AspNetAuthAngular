import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  onSubmit(form: any) {
    if (form.valid) {
      console.log('Form Submitted:', form.value);
    } else {
      console.log('Form is invalid');
    }
  }

  nextStep(){
    console.log('next-click----')
    alert('button-clicked')
  }


  nextStepTwo(){
    console.log('next-click----')
    alert('button-clicked---------------------')
  }



}
