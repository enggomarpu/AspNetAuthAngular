import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotFoundComponent } from './not-found/not-found.component';

import { ErrorComponent } from './error/error.component';
import { PrimaryButtonComponent } from './primary-button/primary-button.component';




@NgModule({
  declarations: [
    NotFoundComponent,
    ErrorComponent,
    PrimaryButtonComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [PrimaryButtonComponent]
})
export class SharedModule { }
